#!/usr/bin/env bash

cd `pwd`/`dirname $0`/java
java start.Main
