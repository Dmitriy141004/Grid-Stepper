#!/usr/bin/env bash

cd `dirname $0`/app
java start.Main
