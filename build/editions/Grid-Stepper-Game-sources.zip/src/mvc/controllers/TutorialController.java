package mvc.controllers;

import mvc.help.FXController;

public class TutorialController extends FXController {
    @Override
    public void init() {
        
    }

    @Override
    public void wakeUp() {

    }

    @Override
    public void shutdown() {

    }
}
