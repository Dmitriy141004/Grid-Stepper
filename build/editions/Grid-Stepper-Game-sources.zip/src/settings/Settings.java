package settings;

import start.Main;
import util.xml.XMLSerializable;

import java.util.HashMap;
import java.util.Map;

/**
 * Class for storing data about application settings.
 *
 * @see Main#appSettings
 */
public class Settings implements XMLSerializable {
    /**
     * Storage of loaded settings.
     * <ul>
     * <li>Key - setting name.</li>
     * <li>Value - setting value.</li>
     * </ul>
     */
    private Map<String, String> settingsStorage = new HashMap<>(0);
    public void setSetting(String key, Object value) {
        String stringVal = value.toString();
        if (settingsStorage.containsKey(key))
            settingsStorage.replace(key, stringVal);
        else
            settingsStorage.put(key, stringVal);
    }
    public String getSetting(String key) {
        return settingsStorage.get(key);
    }

    @Override
    public String toXML() {
        final String indent = Main.XML_SERIALIZE_INDENT;
        StringBuilder builder = new StringBuilder();

        builder.append(generateXMLHeaders(indent));
        for (String key : settingsStorage.keySet())
            builder.append(settingToXML(new Setting(key, settingsStorage.get(key)), indent));
        builder.append(generateXMLClosers(indent));

        return builder.toString();
    }

    private String settingToXML(Setting setting, String indent) {
        return indent + indent + "<setting key=\"" + setting.key + "\" value=\"" + setting.value + "\" />\n";
    }

    private String generateXMLHeaders(String indent) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n\n" +
                "<settings xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                "xsi:noNamespaceSchemaLocation=\"settings-schema.xsd\">\n" +
                indent + "<storage>\n";
    }

    private String generateXMLClosers(String indent) {
        return indent + "</storage>\n" +
                "</settings>\n";
    }

    /**
     * Object for helping serializing.
     *
     * @see #key
     * @see #value
     */
    private class Setting {
        private String key;
        private String value;

        Setting(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }
}
