package util.xml;

/**
 * Interface for class that can be serialized to XML format.
 */
public interface XMLSerializable {
    String toXML();
}
