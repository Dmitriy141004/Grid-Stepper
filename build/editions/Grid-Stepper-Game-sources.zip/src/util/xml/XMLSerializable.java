package util.xml;

/**
 * Interface for class that can be serialized to XML format and back.
 */
public interface XMLSerializable {
    String toXML();
}
